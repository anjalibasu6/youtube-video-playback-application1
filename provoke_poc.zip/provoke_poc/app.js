// Replace 'YOUR_API_KEY' with your actual YouTube Data API key
const apiKey = 'AIzaSyDPafp42H6TKSYT2OFL3f-M5QscrNu-EEY';

// Replace 'YOUR_VIDEO_ID' with the unlisted YouTube video ID
const videoId = 's7YXz7FwMBs';

// Initialize YouTube API
function onYouTubeIframeAPIReady() {
    player = new YT.Player('player', {
        height: '360',
        width: '640',
        videoId: videoId,
        events: {
            'onReady': onPlayerReady,
            'onStateChange': onPlayerStateChange
        }
    });
}

// When the player is ready, start playing the video
function onPlayerReady(event) {
    event.target.playVideo();
}

// You can add more functionality here based on player state changes
function onPlayerStateChange(event) {
    // Example: Pause the video when it ends
    if (event.data == YT.PlayerState.ENDED) {
        player.stopVideo();
    }
}
